# inflate

    Code
      cat(out)
    Output
      tree 8e72c4ca68c095053b2c2dbe08f729a330af1fea
      parent df4a286449005dc0ef54ee6ae80adf5f14d0ecd3
      author G<c3><a1>bor Cs<c3><a1>rdi <csardi.gabor@gmail.com> 1671272030 +0100
      committer G<c3><a1>bor Cs<c3><a1>rdi <csardi.gabor@gmail.com> 1671272030 +0100
      
      Bump to RC version

